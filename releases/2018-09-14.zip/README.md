# swarm-home

`bzz:/theswarm.eth`

or web gateway: http://swarm-gateways.net/bzz:/theswarm.eth/
